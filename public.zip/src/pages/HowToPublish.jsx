import React from 'react';
import Navbar from '../components/Navbar';
import { FaArrowDown } from "react-icons/fa";

const HowToPublish = () => {
    return (
        <>
            <Navbar />
            <div className='bg-gray-100 min-h-[calc(100vh-96px)] flex flex-col items-center'>
                <div className="p-4 max-w-xl mx-auto">
                    <h2 className="font-heading text-gray-900 mb-8 text-3xl font-bold lg:text-4xl">
                        Sed ac magna sit amet risus tristique interdum. hac.
                    </h2>

                    <div className="flex mb-8">
                        <div className="mr-4 flex flex-col items-center">
                            <div>
                                <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-blue-900">
                                    <FaArrowDown className=" text-blue-800" />
                                </div>
                            </div>
                            <div className="h-full w-px bg-gray-300"></div>
                        </div>
                        <div className="pt-1 pb-8">
                            <p className="mb-2 text-xl font-bold text-gray-900">Step 1</p>
                            <p className="text-gray-600">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sagittis, quam nec venenatis lobortis,
                                mirisus tempus nulla, sed porttitor est nibh at nulla. Praesent placerat enim ut ex tincidunt vehicula. Fusce sit amet dui tellus.
                            </p>
                        </div>
                    </div>

                    <div className="flex mb-8">
                        <div className="mr-4 flex flex-col items-center">
                            <div>
                                <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-blue-900">
                                    <FaArrowDown className=" text-blue-800" />

                                </div>
                            </div>
                            <div className="h-full w-px bg-gray-300"></div>
                        </div>
                        <div className="pt-1 pb-8">
                            <p className="mb-2 text-xl font-bold text-gray-900">Step 2</p>
                            <p className="text-gray-600">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sagittis, quam nec venenatis lobortis, mirisus tempus nulla, sed porttitor est nibh at nulla.
                            </p>
                        </div>
                    </div>

                    <div className="flex mb-8">
                        <div className="mr-4 flex flex-col items-center">
                            <div>
                                <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-blue-900">
                                    <FaArrowDown className=" text-blue-800" />

                                </div>
                            </div>
                            <div className="h-full w-px"></div>
                        </div>
                        <div className="pt-1 pb-8">
                            <p className="mb-2 text-xl font-bold text-gray-900">Step 3</p>
                            <p className="text-gray-600">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sagittis, quam nec venenatis lobortis, mirisus tempus nulla, sed porttitor est nibh at nulla.
                            </p>
                        </div>
                    </div>

                    <div className="flex">
                        <div className="mr-4 flex flex-col items-center">
                            <div>
                                <div className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-blue-900 bg-blue-900">
                                    <FaArrowDown className=" text-white" />

                                </div>
                            </div>
                        </div>
                        <div className="pt-1">
                            <p className="mb-2 text-xl font-bold text-gray-900">Ready!</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default HowToPublish;
