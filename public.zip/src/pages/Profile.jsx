import React, { useEffect } from 'react';
import Navbar from '../components/Navbar';
import useAuth from '../hooks/useAuth';
import usePost from '../hooks/usePost';
import { Publication } from '../components/common/Publication';
import { ProfileHeader } from '../components/profile/ProfileHeader';

const Profile = () => {
    const { user } = useAuth();
    const { getMyPost, deletePost } = usePost();
    const { data, isLoading, error, refetch } = getMyPost();

    useEffect(() => {
        refetch()
    }, [refetch])


    return (
        <>
            <Navbar />
            <ProfileHeader user={user}/>
            {(isLoading ? (
                <div className='min-h-[calc(100vh-96px)] flex justify-center items-center'>
                    <span className="loading loading-dots loading-lg"></span>
                </div>
            ) : error ? (
                <div>Error: {error.message}</div>
            ) : (
                <div className='min-h-[calc(100vh-96px)] flex justify-center mb-6'>
                    <div className='max-w-md w-full'>
                        <div className='flex flex-col items-center'>
                            {data.map(post => (
                                <Publication key={post._id} post={post} deletePost={deletePost} user={user} />
                            ))}
                        </div>
                    </div>
                </div>
            ))}

        </>
    );
};

export default Profile;
