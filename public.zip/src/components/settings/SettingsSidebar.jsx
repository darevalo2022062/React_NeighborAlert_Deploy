import React from 'react';

export const SettingsSidebar = () => {
    return (
        <div className="col-span-2 hidden sm:block">
            <ul>
                <li className="mt-5 border-l-2 border-l-[#84BD00] px-2 py-2 font-semibold text-[#84BD00]">Account</li>
            </ul>
        </div>
    );
}


