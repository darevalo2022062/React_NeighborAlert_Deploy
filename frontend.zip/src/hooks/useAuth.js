import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useLoginMutation } from '../services/userApi';
import { setCredentials } from '../features/userSlice';
import { useNavigate } from 'react-router-dom';

const useAuth = () => {
    const dispatch = useDispatch();
    const [login, { isLoading }] = useLoginMutation();
    const { isAuthenticated, user } = useSelector((state) => state.user);
    const navigate = useNavigate()

    const loginRequest = async (data) => {
        try {
            const loginRequest = await login(data).unwrap();
            dispatch(setCredentials(loginRequest));
            navigate('/')
        } catch (err) {
            console.error('Failed to login: ', err);
        }
    }

    return {
        login: loginRequest,
        loading: isLoading,
        isAuthenticated,
        user
    };
}

export default useAuth